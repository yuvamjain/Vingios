# -*- coding: utf-8 -*-
"""
Created on Thu Oct 31 15:02:12 2019

@author: Administrator
"""

from gensim.summarization.summarizer import summarize
import pandas as pd

klera_in = ["text"]
run_from_python = False
if run_from_python:
    text = "the junior all whites have been eliminated from the fifa u - 20 world cup in colombia with results on the final day of pool play confirming their exit . sitting on two points , new zealand needed results in one of the final two groups to go their way to join the last 16 as one of the four best third place teams . but while spain helped the kiwis ' cause with a 5 - 1 thrashing of australia , a 3 - 0 win for ecuador over costa rica saw the south americans climb to second in group c with costa rica 's three points also good enough to progress in third place . that left the junior all whites hopes hanging on the group d encounter between croatia and honduras finishing in a draw . a stalemate - and a place in the knockout stages for new zealand - appeared on the cards until midfielder marvin ceballos netted an 81st minute winner that sent guatemala through to the second round and left the junior all whites packing their bags . new zealand finishes the 24 - nation tournament in 17th place , having claimed their first ever points at this level in just their second appearance at the finals ."
    text = "on-line text—in corpora and especially on the web—renewed interest in automated text summarization. Despite encouraging results, some fundamental ..."
    
try:
    summary = summarize(text, word_count=50)
except Exception as e:
    summary = text
    
if len(summary)==0 or summary == '':
    summary = text

out_dict = {"Text Summary": pd.DataFrame(data={"Summary":summary}, index=[0])}
klera_dst = [out_dict]

klera_scalar = summary
klera_scalar_datatype = "STRING"
klera_scalar_ismultivalue = False
