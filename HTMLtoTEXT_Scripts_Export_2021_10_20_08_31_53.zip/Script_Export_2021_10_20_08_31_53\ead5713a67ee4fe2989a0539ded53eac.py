## Original script
#import re
#
#html_text = """<h3 id="SecutiryConfiguration-Whyissecureconfigurationimportant?">Why is secure configuration important?</h3><p>Manufacturers often set the default configurations of new software and devices to be as open and multi-functional as possible. In the case of a router, for example, this could be a predefined password, or in the case of an operating system, it could be the applications that come preinstalled.</p>"""
#
#text = re.sub(r'<.*?>', '', html_text)


# Modified script according to guidelines
import re
import pandas as pd
# klera_in : List of Input variable names
klera_in =["html_text"]

text = re.sub(r'<.*?>', '', html_text)

# Output Details for Klera Operation
#Define a dictionary of pandas data frames
out_dict = {"HTML to TEXT": pd.DataFrame(data={"Text": [text]})}
# klera_dst : List to hold multiple outputs
klera_dst = [out_dict]

# Output Details for Klera Formula
# Klera Formula output
klera_scalar = text
# Klera Formula data type
klera_scalar_datatype = "STRING"
# Klera Formula isMultivalue
klera_scalar_ismultivalue = False
